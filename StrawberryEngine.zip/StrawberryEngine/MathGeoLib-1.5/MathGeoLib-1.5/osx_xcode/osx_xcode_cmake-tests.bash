#!/bin/bash

cmake -DMATH_TESTS_EXECUTABLE=1 -DFAIL_USING_EXCEPTIONS=1 -G "Xcode" ..


