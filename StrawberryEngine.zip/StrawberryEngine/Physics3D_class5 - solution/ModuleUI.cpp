#include "Globals.h"
#include "Application.h"
#include "ModuleUI.h"


#include <GL/glew.h>

#include "Libs/ImGUI/imgui.h"
#include "Libs/ImGUI/imgui_impl_sdl.h"
#include "Libs/ImGUI/imgui_impl_opengl3.h"

ModuleUI::ModuleUI(Application* app, bool start_enabled) : Module(app, start_enabled)
{
	
}
