cmake -DCMAKE_TOOLCHAIN_FILE=iOS-toolchain.cmake -G "Xcode" ..


